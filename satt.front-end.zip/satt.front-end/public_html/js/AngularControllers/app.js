(function(){
    var satt= angular.module('satt',['simplePagination']);
    
    satt.directive('toolbar', function(){
        return{
            restrict:'E',
            templateUrl: 'partials/toolbar.html',
            controller:function(){
                this.tab=0;
                this.selectTab=function(setTab){
                    this.tab=setTab;
                };
                this.isSelected=function(tabParam){
                    return this.tab===tabParam;
                };
            },
            controllerAs:'toolbar'
        };
    });
   /* satt.directive('todosSensores', function(){
        return{
            restrict:'E',
            templateUrl:'partials/todos-sensores.html',
            controller: 'getSensores'
        };
    });
 
    satt.controller("getSensores", function($http, $scope) {
    $http.get('http://localhost:8081/monitoreo/sensores/').
      success(function(data, status, headers, config) {
        $scope.sensores = data;
      }).
      error(function(data, status, headers, config) {
      });
    });
    */
   satt.directive('todosSensores', function(){
        return{
            restrict: 'E',
            templateUrl: 'partials/todos-sensores.html',
            controller: ['$http', '$scope', 'Pagination', function ($http, $scope, Pagination) {
                    var self = this;
                    $scope.api = function () {
                        var callApi = $http.get('http://quiet-crag-36593.herokuapp.com/monitoreo/sensores?page='
                                + $scope.pagination.page + '&maxRecords=' + $scope.pagination.perPage).success(function (data) {
                            self.sensores = data.sensores;
                            $scope.sensores = data.sensores;
                            $scope.total = data.totalRecords;
                        });
 
                        callApi.then(function () {
                            $scope.pagination.numPages = Math.ceil($scope.total / $scope.pagination.perPage);
                        });
                    }
                    $scope.pagination = Pagination.getNew();
                    $scope.api();
 
                }],
            controllerAs: 'GetSensoresCtrl'
        };
    });
   
    //Actualizacion de sensor
    satt.directive('actualizarForm', function(){
        return{
            restrict:'E',
            templateUrl:'partials/actualizar-form.html',
            controller: 'actualizarCtrl'
        };
    });
 
    satt.controller("actualizarCtrl", function($http, $scope) {
        $scope.actualizar=function(){
            $http.post('http://quiet-crag-36593.herokuapp.com/monitoreo/actualizar/', JSON.stringify($scope.sensor)).success(function(data,headers){
                //$scope.sensor={};
                $scope.toolbar.selectTab(4);
            });
        };
    });
    
    //Visualizacion de boletines antigua
    /*
    satt.directive('todosBoletines', function(){
        return{
            restrict:'E',
            templateUrl:'partials/todos-boletines.html',
            controller: 'getBoletines'
        };
    }); 
    satt.controller("getBoletines", function($http, $scope) {
    $http.get('http://localhost:8082/evento/boletines/').
      success(function(data, status, headers, config) {
        $scope.boletines = data;
      }).
      error(function(data, status, headers, config) {
      });
    });
    */
   
   satt.directive('todosBoletines', function(){
        return{
            restrict: 'E',
            templateUrl: 'partials/todos-boletines.html',
            controller: ['$http', '$scope', 'Pagination', function ($http, $scope, Pagination) {
                    var self = this;
                    $scope.api = function () {
                        var callApi = $http.get('http://quiet-crag-36593.herokuapp.com/boletines?page='
                                + $scope.pagination.page + '&maxRecords=' + $scope.pagination.perPage).success(function (data) {
                            self.boletines = data.boletines;
                            $scope.boletines = data.boletines;
                            $scope.total = data.totalRecords;
                        });
 
                        callApi.then(function () {
                            $scope.pagination.numPages = Math.ceil($scope.total / $scope.pagination.perPage);
                        });
                    }
                    $scope.pagination = Pagination.getNew();
                    $scope.api();
 
                }],
            controllerAs: 'GetBoletinesCtrl'
        };
    });
   
   //Visualizacion de eventos antigua
   /*
    satt.directive('todosEventos', function(){
        return{
            restrict:'E',
            templateUrl:'partials/todos-eventos.html',
            controller: 'getEventos'
        };
    }); 
    satt.controller("getEventos", function($http, $scope) {
    $http.get('http://localhost:8082/evento/eventos/').
      success(function(data, status, headers, config) {
        $scope.eventos = data;
      }).
      error(function(data, status, headers, config) {
      });
    });
   */
    satt.directive('todosEventos', function(){
        return{
            restrict: 'E',
            templateUrl: 'partials/todos-eventos.html',
            controller: ['$http', '$scope', 'Pagination', function ($http, $scope, Pagination) {
                    var self = this;
                    $scope.api = function () {
                        var callApi = $http.get('http://quiet-crag-36593.herokuapp.com/evento/eventos?page='
                                + $scope.pagination.page + '&maxRecords=' + $scope.pagination.perPage).success(function (data) {
                            self.eventos = data.eventos;
                            $scope.eventos = data.eventos;
                            $scope.total = data.totalRecords;
                        });
 
                        callApi.then(function () {
                            $scope.pagination.numPages = Math.ceil($scope.total / $scope.pagination.perPage);
                        });
                    }
                    $scope.pagination = Pagination.getNew();
                    $scope.api();
 
                }],
            controllerAs: 'GetEventosCtrl'
        };
    });
   
   //Gestion de evento sismico
   satt.directive('eventoForm', function(){
        return{
            restrict:'E',
            templateUrl:'partials/evento-form.html',
            controller: 'generarCtrl'
        };
    });
    satt.controller("generarCtrl", function($http, $scope) {
        $scope.generar=function(){
            $http.post('http://quiet-crag-36593.herokuapp.com/evento/generar/', JSON.stringify($scope.evento)).success(function(data,headers){
                //$scope.evento={};
                $scope.toolbar.selectTab(5);
            });
        };
    });
    
})();
