/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function iniciar(lat, long) {
    var lat1= document.getElementById("lat").value;
    var lon1= document.getElementById("lon").value;
   
var mapOptions = {
center: new google.maps.LatLng(lat, long),
zoom: 13,
mapTypeId: google.maps.MapTypeId.ROADMAP};
var map = new google.maps.Map(document.getElementById("map"),mapOptions);
//marcador con la ubicación de la Universidad
var place = new google.maps.LatLng(lat,long);
var marker = new google.maps.Marker({
        position: place
        , title: 'Epicentro'
        , map: map
        , });
//marcador en el centro del mapa

var popup = new google.maps.InfoWindow({
        content: 'Evento Sísmico'});
        popup.open(map, marker);       
        
}              

