/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.services;

import com.example.PersistenceManager;
import com.example.models.Sensor;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import logica.interfaces.IServicioMonitoreoLocal;
import org.codehaus.jettison.json.JSONObject;

/**
 *
 * @author jf.ceron10
 */
@Path("/monitoreo")
@Stateless
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class MonitoreoService {
    
    @PersistenceContext(unitName = "CompetitorsPU")
    EntityManager entityManager;
    
    @PostConstruct
    public void init() {
        try {
            entityManager = PersistenceManager.getInstance().getEntityManagerFactory().createEntityManager();
        } 
        catch (Throwable t) {
            t.printStackTrace();
            if (entityManager.getTransaction().isActive()) {
                entityManager.getTransaction().rollback();
            }
            entityManager.clear();
            entityManager.close();
        } finally {
            //entityManager.clear();
            //entityManager.close();
        }
    }
    
    @POST
    @Path("actualizar/")
    public Sensor actualizar(Sensor s) {
        try {
            entityManager.getTransaction().begin();
            entityManager.persist(s);
            entityManager.getTransaction().commit();
            System.out.println("Agregado correctamente (sensor)");
        }
        catch (Exception e) {
            e.printStackTrace();
            
            if (entityManager.getTransaction().isActive()) entityManager.getTransaction().rollback();
            entityManager.clear();
            entityManager.close();
        }
        return s;
    }
    
    @POST
    @Path("actualizars/")
    public Sensor actualizars(List<Sensor> ss) {
        JSONObject rta = new JSONObject();
        
        try {
            if (ss.size()==0) return new Sensor();
            entityManager.getTransaction().begin();
            for (Sensor s : ss) entityManager.persist(s);
            entityManager.getTransaction().commit();
                
            System.out.println("Agregados correctamente "+ss.size()+" elementos");
        }
        catch (Exception e) {
            e.printStackTrace();
            
            if (entityManager.getTransaction().isActive()) entityManager.getTransaction().rollback();
            entityManager.clear();
            entityManager.close();
        }
        return ss.get(0);
    }
    
    @GET
    @Path("sensores/")
    public List<Sensor> getSensores() {
        Query q = entityManager.createQuery("select u from Sensor u order by u.zona ASC");
        List<Sensor> sensores = q.getResultList();
        return sensores;
    }
}