package logica.interfaces;
import com.example.models.Sensor;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author jf.ceron10
 */
@Local
public interface IServicioMonitoreoLocal {
    public void actualizarSensor(Sensor s);
    public List<Sensor> getSensores();
}
