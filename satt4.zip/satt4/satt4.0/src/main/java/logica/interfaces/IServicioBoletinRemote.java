package logica.interfaces;

import com.example.models.Boletin;
import com.example.models.Evento;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author jf.ceron10
 */
@Remote
public interface IServicioBoletinRemote {
    public Evento generarEvento(Evento e );
    public List<Boletin> getBoletines();
    public List<Evento> getEventos();
}