// Archivo inicial pagination.js
(function() {
  "use strict";
 
  var paginationModule = angular.module('simplePagination', []);
 
  paginationModule.factory('Pagination', function() {
   // Agregar aquí la Definición de métodos y caracterización del objeto de tipo pagination
  });
 
})();