/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.services;

import com.example.models.Boletin;
import com.example.models.Sensor;
import com.example.models.Zona;
import java.util.ArrayList;
import java.util.HashMap;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 *
 * @author jf.ceron10
 */
public class ThreadSeguimiento extends Thread {
    
   
    private Sensor cercano;
    private double distancia;
    private boolean monitoreo;
    private boolean primera;
    EntityManager entityManager;
    HashMap<String,Zona> zonas;

    /**
     *
     * @param persistencia
     */
    public ThreadSeguimiento (EntityManager entityManager, Sensor cercano, double distancia) {
        this.entityManager=entityManager;
        this.cercano=cercano;
        this.distancia=distancia;
        monitoreo=true;
        primera=true;
        
        zonas=new HashMap();
        zonas.put("A_Guajira", new Zona("A_Guajira", 6000, 5));
        zonas.put("A_Magdalena", new Zona("A_Magdalena", 5000, 8));
        zonas.put("A_Sucre", new Zona("A_Sucre", 6000, 14.5));
        zonas.put("A_Cordoba", new Zona("A_Cordoba", 5000, 16));
        zonas.put("A_Antioquia", new Zona("A_Antioquia", 10000, 10));
        zonas.put("P_Choco", new Zona("P_Choco", 8000, 5));
        zonas.put("P_Valle", new Zona("P_Valle", 9000, 11));
        zonas.put("P_Cauca", new Zona("P_Cauca", 7500, 13));
        zonas.put("P_Narino", new Zona("P_Narino", 16000, 13.12));
        
        start();
    }
    
    @Override
    public void run() {
        
        double ultimaAltura=0;
        while (monitoreo) {
            //Se deduce el tiempo
            double tiempoLlegada=distancia/cercano.getVelocidad();
            
            //Se determina el perfil de alerta dados los parametros y zona
            int urgencia=0;
            Zona zona=zonas.get(cercano.getZona());
            if (tiempoLlegada<=zona.gettMax()) urgencia++;
            if (cercano.getAltura()>=zona.getAlturaMin()) urgencia++;
            if (zona.getNombre().startsWith("P")) urgencia++;
            else if (cercano.getAltura()>=zona.getAlturaMin()*1.5) urgencia++;
            
            String perfil;
            if (urgencia==0) perfil="informativo";
            else if (urgencia==1) perfil="precaucion";
            else if (urgencia==2) perfil="alerta";
            else perfil="alarma";
            
            if (Math.abs(ultimaAltura-cercano.getAltura())>1.5 || primera) {
                ultimaAltura=cercano.getAltura();
                
                System.out.println(perfil);
                System.out.println(zona.getNombre());
                System.out.println(tiempoLlegada);
                System.out.println(ultimaAltura);
                
                Boletin boletin=new Boletin(perfil, zona.getNombre(), tiempoLlegada, ultimaAltura);
                try {
                    //Se envia la informacion a la Direccion de Gestion del Riesgo
                    
                    entityManager.getTransaction().begin();
                    boletin.setSinc(false);
                    entityManager.persist(boletin);
                    entityManager.getTransaction().commit();
                    System.out.println("Agregado correctamente (boletin)");
                    
                    
                    //Se esperan 5 minutos antes de verificar si es necesaria una actualizacion
                    sleep(60000);
                } catch (Exception ex) {
                    ex.printStackTrace();
                    
                    if (entityManager.getTransaction().isActive()) entityManager.getTransaction().rollback();
                    entityManager.clear();
                    entityManager.close();
                }
                distancia-=cercano.getVelocidad()*5*60;
                primera=false;
            }
            else monitoreo=false;
        }
    }
}