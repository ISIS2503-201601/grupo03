/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.models;

import java.util.List;

/**
 *
 * @author jf.ceron10
 */
public class BoletinPage {

    public List<Boletin> getBoletines() {
        return boletines;
    }

    public void setBoletines(List<Boletin> boletines) {
        this.boletines = boletines;
    }

    public long getTotalRecords() {
        return totalRecords;
    }

    public void setTotalRecords(long totalRecords) {
        this.totalRecords = totalRecords;
    }
    
    public BoletinPage(){
    // Se asignan los valores desde otra clase, no hay que inicializar
    }
    
    private List<Boletin> boletines;
    private long totalRecords;
}
