/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.services;

import com.example.PersistenceManager;
import com.example.models.Respuesta;
import com.example.models.Sensor;
import com.example.models.SensorPage;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 *
 * @author jf.ceron10
 */
@Path("/monitoreo")
@Stateless
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class MonitoreoService {
    private String IPotro="172.24.100.42";
    
    @PersistenceContext(unitName = "AplicacionMundialPU")
    EntityManager entityManager;
    
    @PostConstruct
    public void init() {
        try {
            entityManager = PersistenceManager.getInstance().getEntityManagerFactory().createEntityManager();
        }
        catch (Throwable t) {
            t.printStackTrace();
            if (entityManager.getTransaction().isActive()) {
                entityManager.getTransaction().rollback();
            }
            entityManager.clear();
            entityManager.close();
        } finally {
            
        }
    }
    
    @POST
    @Path("replicar/")
    public Respuesta replicar(List<Sensor> sensores) {
        try {
            entityManager.getTransaction().begin();
            for (Sensor s:sensores) {
                entityManager.persist(s);
            }
            entityManager.getTransaction().commit();
            System.out.println("Sincronizado correctamente (sensor)");
        }
        catch (Exception e) {
            e.printStackTrace();
            if (entityManager.getTransaction().isActive()) entityManager.getTransaction().rollback();
            entityManager.clear();
            entityManager.close();
            return new Respuesta("error");
        }
        return new Respuesta("exito");
    }
    
   
    @PUT
    @Path("sincronizar/")
    public Respuesta sincronizar () {
        boolean syncOK=false;
        try {
            Query q = entityManager.createQuery("select s from Sensor s where s.sinc=0");
            List<Sensor> sensores=q.getResultList();
            
            JSONArray jsonArray=new JSONArray();
            JSONObject jsonObject;
            ArrayList<String> ids=new ArrayList();
            for (Sensor s: sensores) {
                jsonObject = new JSONObject();
                jsonObject.put("altura", s.getAltura());
                jsonObject.put("createdAt", s.getCreatedAt().getTimeInMillis());
                jsonObject.put("latitud", s.getLatitud());
                jsonObject.put("longitud", s.getLongitud());
                jsonObject.put("velocidad", s.getVelocidad());
                jsonObject.put("zona", s.getZona());
                jsonObject.put("sinc", "true");
                jsonArray.add(jsonObject);
                
                ids.add(""+s.getId());
            }
            
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://"+IPotro+":8081/monitoreo/replicar/");
            httppost.setEntity(new StringEntity(jsonArray.toJSONString(), "UTF8"));
            httppost.setHeader("Content-type", "application/json");
            HttpResponse response = httpclient.execute(httppost);
            String jsonString=EntityUtils.toString(response.getEntity());
            System.out.println("JSON string obtenido "+jsonString);
            JSONParser parser = new JSONParser();
            jsonObject = (JSONObject) parser.parse(jsonString);
            
            syncOK="exito".equals(jsonObject.get("respuesta"));
            
            if (syncOK) {
                entityManager.getTransaction().begin();
                for (String id : ids) {
                    q = entityManager.createQuery("update Sensor s set s.sinc=1 where s.id="+id);
                    q.executeUpdate();
                }
                entityManager.getTransaction().commit();
            }
            else return new Respuesta("error");
            System.out.println("Sincronizado correctamente (sensor)");
        }
        catch (Exception e) {
            e.printStackTrace();
            
            if (entityManager.getTransaction().isActive()) entityManager.getTransaction().rollback();
            entityManager.clear();
            entityManager.close();
            return new Respuesta("error");
        }
        return new Respuesta("exito");
    }
    
    @POST
    @Path("actualizarVarios/")
    public Respuesta actualizar(List<Sensor> ss) {
        if (ss.isEmpty()) return new Respuesta("exito, lista vacia");
        entityManager.getTransaction().begin();
        List<String> ids=new ArrayList();
        
        try {
            for (Sensor s : ss) {
                if (s.getVelocidad()==0)s.setVelocidad(1);
                entityManager.persist(s);
                ids.add(""+s.getId());
            }
            entityManager.getTransaction().commit();
            System.out.println("Agregados correctamente "+ss.size()+" elementos");
            return new Respuesta("Agregados correctamente "+ss.size()+" elementos"); 
        }
        catch (Exception e) {
            e.printStackTrace();
            
            if (entityManager.getTransaction().isActive()) entityManager.getTransaction().rollback();
            entityManager.clear();
            entityManager.close();
            return new Respuesta("error");
        }
        
       
    }
    @POST
    @Path("actualizar/")
    public Respuesta actualizar(Sensor s) {
        if (s.getVelocidad()==0)s.setVelocidad(1);
        try {
            entityManager.getTransaction().begin();
            entityManager.persist(s);
            entityManager.getTransaction().commit();
            
            return new Respuesta("Agregado correctamente"); 
        }
        catch (Exception e) {
            e.printStackTrace();
            
            if (entityManager.getTransaction().isActive()) entityManager.getTransaction().rollback();
            entityManager.clear();
            entityManager.close();
            return new Respuesta("error");
        }
    }
    
    
   
    @GET
    @Path("sensores/")
    public SensorPage getSensores(@QueryParam("page") Integer page, @QueryParam("maxRecords") Integer maxRecords, 
            @QueryParam("lat") String lat, @QueryParam("lon") String lon, @QueryParam("desde") String desde, 
            @QueryParam("hasta") String hasta, @QueryParam("zona") String zona) {
        SensorPage sensorPage=new SensorPage();
                
        String params="";
        if (lat!=null) params+=" where u.latitud="+lat;
        if (lon!=null) {
            if (params.equals("")) params+=" where u.longitud="+lon;
            else params+=" and u.longitud="+lon;
        }
        if (desde!=null){
            if (params.equals("")) params+=" where u.createdAt>='"+desde+"'";
            else params+=" and u.createdAt>='"+desde+"'";
        }
        if (hasta!=null){
            if (params.equals("")) params+=" where u.createdAt<='"+hasta+"'";
            else params+=" and u.createdAt<='"+hasta+"'";
        }
        if (zona!=null){
            if (params.equals("")) params+=" where u.zona='"+zona+"'";
            else params+=" and u.zona='"+zona+"'";
        }
        
        //Conteo de registros
        Query count = entityManager.createQuery("select count(u) from Sensor u"+params);
        Long regCount ;
        regCount = Long.parseLong(count.getSingleResult().toString());

        Query q = entityManager.createQuery("select u from Sensor u"+params+" order by u.createdAt desc");
        if(page != null && maxRecords != null){
            q.setFirstResult((page-1)*maxRecords);
            q.setMaxResults(maxRecords);
        }
        sensorPage.setSensores(q.getResultList());
        sensorPage.setTotalRecords(regCount);
        return sensorPage;
    }
}