/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author jf.ceron10
 */
@Entity
public class Zona {
    private static final long serialVersionUID = 1L;

    public Zona(String nombre, double tMax, double alturaMin) {
        this.nombre = nombre;
        this.tMax = tMax;
        this.alturaMin = alturaMin;
    }
    public Zona (){
    // Se asignan los valores desde otra clase, no hay que inicializar
    }
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double gettMax() {
        return tMax;
    }

    public void settMax(double tMax) {
        this.tMax = tMax;
    }

    public double getAlturaMin() {
        return alturaMin;
    }

    public void setAlturaMin(double alturaMin) {
        this.alturaMin = alturaMin;
    }

   
    private String nombre;
    //Tiempo maximo de llegada de la ola para disparar alarma
    private double tMax;
    //Altura minima de la ola para disparar alarma
    private double alturaMin;
}
