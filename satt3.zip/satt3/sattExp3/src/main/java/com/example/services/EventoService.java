/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.services;

import com.example.PersistenceManager;
import com.example.models.Boletin;
import com.example.models.BoletinPage;
import com.example.models.Evento;
import com.example.models.EventoPage;
import com.example.models.Respuesta;
import com.example.models.Sensor;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 *
 * @author jf.ceron10
 */
@Path("/evento")
@Stateless
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class EventoService {
    
    
    @PersistenceContext(unitName = "AplicacionMundialPU")
    EntityManager entityManager;
    
    @PostConstruct
    public void init() {
        try {
            entityManager = PersistenceManager.getInstance().getEntityManagerFactory().createEntityManager();
        } 
        catch (Throwable t) {
            t.printStackTrace();
            if (entityManager.getTransaction().isActive()) {
                entityManager.getTransaction().rollback();
            }
            entityManager.clear();
            entityManager.close();
        } finally {
           
        }
    }
    
    @POST
    @Path("replicar/eventos")
    public Respuesta replicarEventos(List<Evento> eventos) {
        try {
            entityManager.getTransaction().begin();
            for (Evento e:eventos) {
                entityManager.persist(e);
            }
            entityManager.getTransaction().commit();
            System.out.println("Sincronizado correctamente (sensor)");
        }
        catch (Exception e) {
            e.printStackTrace();
            if (entityManager.getTransaction().isActive()) entityManager.getTransaction().rollback();
            entityManager.clear();
            entityManager.close();
            return new Respuesta("error");
        }
        return new Respuesta("exito");
    }
    @POST
    @Path("replicar/boletines")
    public Respuesta replicarBoletines(List<Boletin> boletines) {
        try {
            entityManager.getTransaction().begin();
            for (Boletin b:boletines) {
                entityManager.persist(b);
            }
            entityManager.getTransaction().commit();
            System.out.println("Sincronizado correctamente (boletin)");
        }
        catch (Exception e) {
            e.printStackTrace();
            if (entityManager.getTransaction().isActive()) entityManager.getTransaction().rollback();
            entityManager.clear();
            entityManager.close();
            return new Respuesta("error");
        }
        return new Respuesta("exito");
    }
    
    @POST
    @Path("generar/")
    public Respuesta generarEvento(Evento e) {
        //Se introduce el evento a la base de datos
        try {
            entityManager.getTransaction().begin();
            e.setSinc(false);
            entityManager.persist(e);
            entityManager.getTransaction().commit();
            System.out.println("Agregado correctamente (evento)");
        }
        catch (Exception x) {
            x.printStackTrace();
            
            if (entityManager.getTransaction().isActive()) entityManager.getTransaction().rollback();
            entityManager.clear();
            entityManager.close();
            return new Respuesta("error");
        }
        
        
        double[][] coordenadas= new double[4000][2];
        for (int i=0;i<4000;i++) {
            coordenadas[i][0]=0.0025*i;
            coordenadas[i][1]=0.0025*i;
        }
        double latEvento=e.getLatitud();
        double lonEvento=e.getLongitud();
        
        //Se localiza el sensor mas cercano al evento
        double distanciaMinima=Integer.MAX_VALUE;
        double latCercano=0;
        double lonCercano=0;
        
        for(int i=0;i<4000;i++) {
            double dist=distancia(coordenadas[i][0], latEvento, coordenadas[i][1], lonEvento);
            
            if (dist<distanciaMinima) 
            {
                distanciaMinima=dist;
                latCercano=coordenadas[i][0];
                lonCercano=coordenadas[i][1];
            }
        }
        
     
        //Se consigue el ultimo registro del sensor mas cercano
      
        Query q = entityManager.createQuery("select u from Sensor u where u.latitud="+latCercano+" and u.longitud="+lonCercano);
        Sensor cercano=(Sensor) q.getResultList().get(0);
        if (cercano==null) (new Exception("Sensor cercano no encontrado")).printStackTrace();
        
        //Se inicializa un Thread que se encarga del seguimiento
        new ThreadSeguimiento(entityManager, cercano, distanciaMinima);
        
        return new Respuesta("exito");
    }
    
    @GET
    @Path("boletines/")
    public BoletinPage getBoletines (@QueryParam("page") Integer page, @QueryParam("maxRecords") Integer maxRecords) {
        //Conteo de registros
        Query count = entityManager.createQuery("select count(u) from Boletin u");
        Long regCount ;
        regCount = Long.parseLong(count.getSingleResult().toString());

        Query q = entityManager.createQuery("select u from Boletin u order by u.createdAt desc");
        if(page != null && maxRecords != null){
            q.setFirstResult((page-1)*maxRecords);
            q.setMaxResults(maxRecords);
        }
        BoletinPage bolePage=new BoletinPage();
        bolePage.setBoletines(q.getResultList());
        bolePage.setTotalRecords(regCount);
        return bolePage;
    }
    
    @GET
    @Path("eventos/")
    public EventoPage getEventos (@QueryParam("page") Integer page, @QueryParam("maxRecords") Integer maxRecords) {
        //Conteo de registros
        Query count = entityManager.createQuery("select count(u) from Evento u");
        Long regCount ;
        regCount = Long.parseLong(count.getSingleResult().toString());

        Query q = entityManager.createQuery("select u from Evento u order by u.createdAt desc");
        if(page != null && maxRecords != null){
            q.setFirstResult((page-1)*maxRecords);
            q.setMaxResults(maxRecords);
        }
        EventoPage evenPage=new EventoPage();
        evenPage.setEventos(q.getResultList());
        evenPage.setTotalRecords(regCount);
        return evenPage;
    }
   
    
    private double distancia (double lat1, double lat2, double lon1, double lon2) {
        double sec1 = Math.sin(lat1)*Math.sin(lat2);
        double dl=Math.abs(lon1-lon2);
        double sec2 = Math.cos(lat1)* Math.cos(lat2);
        double centralAngle = Math.acos(sec1+sec2*Math.cos(dl));
        return  centralAngle * 6378.1;
    }
}
