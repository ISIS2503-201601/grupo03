/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.models;

/**
 *
 * @author jf.ceron10
 */
public class Respuesta {

    public Respuesta() {
    // Se asignan los valores desde otra clase, no hay que inicializar
    }
    public Respuesta(String respuesta) {
        this.resp=respuesta;
    }
    
    public String getRespuesta() {
        return resp;
    }

    public void setRespuesta(String respuesta) {
        this.resp = respuesta;
    }
    private String resp;
}
